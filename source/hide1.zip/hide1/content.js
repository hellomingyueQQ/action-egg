let overlay;
let isResizing = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(request);
    if (request) {
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id="test111"
            overlay.style.position = 'fixed';
            overlay.style.backgroundColor = 'yellowgreen';
            overlay.style.cursor = 'move';
            overlay.style.zIndex = '9999999';
            document.body.appendChild(overlay);

            const resizeHandle = document.createElement('div');
            resizeHandle.style.width = '10px';
            resizeHandle.style.height = '10px';
            resizeHandle.style.backgroundColor = 'red';
            resizeHandle.style.position = 'absolute';
            resizeHandle.style.right = '0';
            resizeHandle.style.bottom = '0';
            resizeHandle.style.cursor = 'nwse-resize';
            overlay.appendChild(resizeHandle);

            overlay.onmousedown = (e) => {
                if (!isResizing) {
                    const offsetX = e.clientX - overlay.getBoundingClientRect().left;
                    const offsetY = e.clientY - overlay.getBoundingClientRect().top;

                    const mouseMoveHandler = (e) => {
                        overlay.style.left = `${e.clientX - offsetX}px`;
                        overlay.style.top = `${e.clientY - offsetY}px`;
                    };

                    document.addEventListener('mousemove', mouseMoveHandler);
                    document.onmouseup = () => {
                        document.removeEventListener('mousemove', mouseMoveHandler);
                        document.onmouseup = null;
                    };
                }
            };

            resizeHandle.onmousedown = (e) => {
                isResizing = true;
                e.stopPropagation();

                const initialWidth = overlay.offsetWidth;
                const initialHeight = overlay.offsetHeight;
                const initialMouseX = e.clientX;
                const initialMouseY = e.clientY;

                const mouseMoveHandler = (e) => {
                    const newWidth = initialWidth + (e.clientX - initialMouseX);
                    const newHeight = initialHeight + (e.clientY - initialMouseY);
                    overlay.style.width = `${newWidth}px`;
                    overlay.style.height = `${newHeight}px`;
                   // overlay.style.left = `${(window.innerWidth - newWidth) / 2}px`;
                    //overlay.style.top = `${(window.innerHeight - newHeight) / 2}px`;
                };

                document.addEventListener('mousemove', mouseMoveHandler);
                document.onmouseup = () => {
                    isResizing = false;
                    document.removeEventListener('mousemove', mouseMoveHandler);
                    document.onmouseup = null;
                };
            };
        }

        overlay.style.width = `${request.width}px`;
        overlay.style.height = `${request.height}px`;
        overlay.style.left = `${(window.innerWidth - request.width) / 2}px`;
        overlay.style.top = `${(window.innerHeight - request.height) / 2}px`;
    }
});
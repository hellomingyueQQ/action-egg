document.getElementById('apply').addEventListener('click', () => {
    const width = document.getElementById('width').value; // 获取宽度值
    const height = document.getElementById('height').value; // 获取高度值
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {width: width, height: height}); // 发送宽度和高度
    });
});
